# Account Generator
A simple bot that will help you giving accounts to your server's members.  
For any issue, contact me on discord: Mental#8106
# Packages
-discord.js  
-async  
-firstline  
-line-reader  

# Usage
This bot won't give you free accounts, you need to create your personal stock by creating a .txt file  
Example: netflix.txt - spotify.txt - amazon.txt - fortnite.txt  

Then the user needs to specify the service he wants  
Example: /gen netflix  - The bot will search for netflix.txt file and take an account.

