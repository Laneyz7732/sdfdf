Welcome to discord bot
=================
open source discord bot
------------

On the front-end,
- edit `commands` 

Made by mrscary
-------------------

\ ゜o゜)ノ
